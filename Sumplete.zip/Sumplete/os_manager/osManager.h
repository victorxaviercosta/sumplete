#ifndef OS_MANAGER_H
#define OS_MANAGER_H

#include <stdio.h>
#include <stdlib.h>
#include "../tools/formats.h"

void clear();

void splash(char* string);

#endif //OS_MANAGER_H